function dF=GetODEs(~,w,par,Lext,Jext,disa)

% parmeters
D0=par(1);J0=par(2);beta=par(3);kho=par(4);khe=par(5);
kt=par(6);kc=par(7);N0=par(8);r=par(9);alpha=par(10);

% ode system
dF=[D0-beta*w(1)-2*kho*w(1)^2-khe*w(1)*w(2)+2*disa*w(3);
    J0-beta*w(2)-khe*w(1)*w(2);
    kho*w(1)^2-beta*w(3)-kc*w(3)*w(4)-disa*w(3);
    N0-beta*w(4)-kt*(Lext+alpha*Jext)*w(4)-kc*w(3)*w(4);
    kt*(Lext+alpha*Jext)*w(4)-r*w(5)];

end
