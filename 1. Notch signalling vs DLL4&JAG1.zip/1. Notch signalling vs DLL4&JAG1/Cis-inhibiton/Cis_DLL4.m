% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=0;J0=0; %production of ligands
beta=0.1; %degradation rate
N0=500;   %production of Notch
kho=0.0001;khe=0.1; %dimerization rate
kt=5*10^(-5); %trans-activation and VEGF-VEGFR binding
kc=6*10^(-4); %trans-activation and VEGF-VEGFR binding
r=0.5;  %degradation rate of signaling of Notch and VEGF
alpha=0.0001;
par=[D0 J0 beta kho khe kt kc N0 r alpha];

%% Initial condition
Lext=1000;Jext=0;
W0=unifrnd(0,100,1,5); %initial value of ODE
T=5000; %calculating period

%% Solving ODE by Runge-Kutta solver
for k = 1:101
    p1(k)=25*(k-1);
    par(1)= p1(k);
    [~,Y]=ode45(@GetODEs,0:1:T,W0,[],par,Lext,Jext);
    out(k)=Y(end,5);
end

%% Output results
plot(p1,out,'LineWidth',3,'Color',[0.3,0.52,0.74])
axis([0 2500 0 400]);
title('Cis-JAG1 (b_J=0)');
xlabel('Production rate of cis-DLL4 (b_D)')
ylabel('Notch activity (NICD)')
set(gca,'FontSize',18)
