% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=0;J0=0; %production of ligands
beta=0.1; %degradation rate
N0=500;   %production of Notch
kho=0.0001;khe=0.0; %dimerization rate
kt=5*10^(-5); %trans-activation and VEGF-VEGFR binding
kc=6*10^(-4); %trans-activation and VEGF-VEGFR binding
r=0.5;  %degradation rate of signaling of Notch and VEGF
alpha=0.0001;
par=[D0 J0 beta kho khe kt kc N0 r alpha];

%% Initial condition
Lext=1000;Jext=0;
W0=unifrnd(0,100,1,5); %initial value of ODE
T=5000; %calculating period

%% Solving ODE by Runge-Kutta solver
for i = 1:11
    p1(i)=250*(i-1);
    par(1)= p1(i);
    for j= 1:11
        p2(j)=250*(j-1);
        par(2)=p2(j);
        [~,Y]=ode45(@GetODEs,0:1:T,W0,[],par,Lext,Jext);
        out(i,j)=Y(end,5);
    end
end

%% Output results
[~,h]=contourf(p1,p2,out');
set(h,'Color','none');
title('Without heterodimerization');
xlabel('Production rate of cis-DLL4 (b_D)');
ylabel('Production rate of cis-JAG1 (b_J)');
h=colorbar;
h.Label.String='Notch activity (NICD)';
set(gca,'FontSize',18)
