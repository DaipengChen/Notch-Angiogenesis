function dF=GetODEs(~,w,par,decay)
D0=par(1);J0=par(2);beta=par(3);kho=par(4);khe=par(5);
kt=par(6);kc=par(7);N0=par(8);r=par(9);alpha=par(10);

beta1=decay(1);beta2=decay(2);beta3=decay(3);beta4=decay(4);

% ode system
dF=[D0-beta1*w(1)-2*kho*w(1)^2-khe*w(1)*w(2)-kt*w(1)*w(9);
    J0-beta2*w(2)-khe*w(1)*w(2)-alpha*kt*w(2)*w(9);
    kho*w(1)^2-beta3*w(3)-kc*w(3)*w(4);
    N0-beta4*w(4)-kt*(w(6)+alpha*w(7))*w(4)-kc*w(3)*w(4);
    kt*(w(6)+alpha*w(7))*w(4)-r*w(5);
    0-beta1*w(6)-2*kho*w(6)^2-khe*w(6)*w(7)-kt*w(6)*w(4);
    0-beta2*w(7)-khe*w(6)*w(7)-alpha*kt*w(7)*w(4);
    kho*w(6)^2-beta3*w(8)-kc*w(8)*w(9);
    N0-beta4*w(9)-kt*(w(1)+alpha*w(2))*w(9)-kc*w(8)*w(9);
    kt*(w(1)+alpha*w(2))*w(9)-r*w(10)];

end