% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=2500;J0=0; %production of ligands
beta=0.1; %degradation rate
N0=500;   %production of Notch
kho=0.0001;khe=0.0; %dimerization rate
kt=5*10^(-5); %trans-activation and VEGF-VEGFR binding
kc=6*10^(-4); %trans-activation and VEGF-VEGFR binding
r=0.5;  %degradation rate of signaling of Notch and VEGF
alpha=0.0001;
par=[D0 J0 beta kho khe kt kc N0 r alpha];

%% Initial condition
W0=unifrnd(0,100,1,10); %initial value of ODE
T=5000; %calculating period

deg_rate=[0.05,0.15,0.25];
decay=ones(27,4);
loop=0;

%% Solving ODE by Runge-Kutta solver
for i=1:length(deg_rate)
    beta1=deg_rate(i);
    for j=1:length(deg_rate)
        beta2=deg_rate(j);
        for k=1:length(deg_rate)
            beta3=deg_rate(k);
            for s=1:length(deg_rate)
                beta4=deg_rate(s);
                decay(loop+1,:)=[beta1,beta2,beta3,beta4];
                loop=loop+1;
            end
        end
    end
end

for i=1:loop
    degradation=decay(i,:);
    for j=1:11
        p(j)=250*(j-1);
        par(2)= p(j);
        [~,Y]=ode45(@GetODEs,0:1:T,W0,[],par,degradation);
        out(i,j)=Y(end,10);
    end
end

%% Output results
for i=1:loop
    plot(p,out(i,:))
    hold on
end
axis([0 2500 0 1000]);
text(100,75,'Without heterodimerization','FontSize',18);
text(100,175,'Low Notch1-JAG1 affinity','FontSize',18);
title('Trans-DLL4 (b_D=2500)');
xlabel('Production rate of trans-JAG1 (b_J)')
ylabel('Notch activity (NICD)')
set(gca,'FontSize',18)

