% This code is for simulating the notch acitivity with different expression
% level of internal ligands.
% Written by Daipeng Chen (26 July, 2021)

clc
clear
close all

%% Parameter setting
D0=2500;J0=0; %production of ligands
beta=0.1; %degradation rate
N0=500;   %production of Notch
kho=0.0001;khe=0.001; %dimerization rate
kt=5*10^(-5); %trans-activation and VEGF-VEGFR binding
kc=6*10^(-4); %trans-activation and VEGF-VEGFR binding
r=0.5;  %degradation rate of signaling of Notch and VEGF
alpha=0.0001;
par=[D0 J0 beta kho khe kt kc N0 r alpha];

%% Initial condition
W0=unifrnd(0,100,1,10); %initial value of ODE
T=5000; %calculating period

%% Solving ODE by Runge-Kutta solver
for k = 1:101
    p(k)=25*(k-1);
    par(2)= p(k);
    par(5)=khe;par(10)=0;
    [~,Y1]=ode45(@GetODEs,0:1:T,W0,[],par);
    par(5)=khe;par(10)=1;
    [~,Y2]=ode45(@GetODEs,0:1:T,W0,[],par);
    par(5)=0;par(10)=0;
    [~,Y3]=ode45(@GetODEs,0:1:T,W0,[],par);
    par(5)=0;par(10)=1;
    [~,Y4]=ode45(@GetODEs,0:1:T,W0,[],par);
    out1(k)=Y1(end,10);
    out2(k)=Y2(end,10);
    out3(k)=Y3(end,10);
    out4(k)=Y4(end,10);
end

%% Output results
plot(p,out1,'LineWidth',3,'Color',[0.3,0.52,0.74])
hold on
plot(p,out2,'-.','LineWidth',3,'Color',[0.3,0.52,0.74])
hold on
plot(p,out3,'LineWidth',3,'Color',[0.97,0.56,0.24])
hold on
plot(p,out4,'-.','LineWidth',3,'Color',[0.97,0.56,0.24])
axis([0 2500 0 1000]);
legend('Low Notch1-JAG1 affinity (\alpha=0)','High Notch1-JAG1 affinity (\alpha=1)',...
    'location','southwest');
title('Trans-DLL4 (b_D=2500)');
xlabel('Production rate of trans-JAG1 (b_J)')
ylabel('Notch activity (NICD)')
set(gca,'FontSize',18)
