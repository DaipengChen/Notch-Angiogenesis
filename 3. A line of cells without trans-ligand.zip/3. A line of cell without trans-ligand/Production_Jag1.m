% This code is for investigating the dynamics of VEGF-Delta-Notch signaling
% in two cell system.
% Written by Daipeng Chen (15 Dec, 2021)

clc
clear
close all

%% Parameter setting
D0=100;J0=0;
m=1; %initial cell number in y aixs
n=20; %initial cell number in x axis
p1=[1 10 25 100 200 300 2000 2500 3000];

%% Initial condition
t=-pi/2:pi/3:3*pi/2;
x=sin(t+pi/2);y=cos(t+pi/2); %the shape of cells
simnum=length(p1); %the number of simulations

%% Calculation
for i=1:simnum
    J0 = p1(i);
    [DLL4,JAG1,Snotch,Svegf]=linecell(D0,J0,m,n);
    D4(i,:)=DLL4;
    J1(i,:)=JAG1;
    Sn(i,:)=Snotch;
    Sv(i,:)=Svegf;
end

%% Output figure
pow=5;
annotation('arrow',[0.05,0.05],[0.35,0.92],'LineStyle','-','color','k','LineWidth',2)
annotation('line',[0.955,0.955],[0.37,0.53],'LineStyle','-','color','k','LineWidth',1)
annotation('line',[0.955,0.955],[0.55,0.71],'LineStyle','-','color','k','LineWidth',1)
annotation('line',[0.955,0.955],[0.73,0.89],'LineStyle','-','color','k','LineWidth',1)
text(-0.124,0.31,'JAG1 production rate (b_J)','rotation',90,'fontsize',15)
text(1.079,0.34,'JAG1^{+/-}','rotation',90,'fontsize',12)
text(1.079,0.60,'WT','rotation',90,'fontsize',12)
text(1.079,0.76,'JAG1^{iGOF}','rotation',90,'fontsize',12)
box on
axis off

for k=1:simnum
nu=1;
S1=D4(k,:);
axes('position',[0.06,0.37+0.06*(k-1),0.215,0.04]);
for i=1:m
    for j=1:n
        xp=x+sqrt(3)*(j-1)+((-1)^i+1)*sqrt(3)/4;
        yp=y+3*(i-1)/2;
        sf=S1(nu)^pow/(S1(nu)^pow+250^pow);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        axis([-1 34 -1 1])
        hold on
        nu=nu+1;
    end
end
axis off
end


for k=1:simnum
nu=1;
S2=J1(k,:);
axes('position',[0.285,0.37+0.06*(k-1),0.215,0.04]);
for i=1:m
    for j=1:n
        xp=x+sqrt(3)*(j-1)+((-1)^i+1)*sqrt(3)/4;
        yp=y+3*(i-1)/2;
        sf=S2(nu)^pow/(S2(nu)^pow+250^pow);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        axis([-1 34 -1 1])
        hold on
        nu=nu+1;
    end
end
axis off
end


for k=1:simnum
nu=1;
S3=Sn(k,:);
axes('position',[0.51,0.37+0.06*(k-1),0.215,0.04]);
for i=1:m
    for j=1:n
        xp=x+sqrt(3)*(j-1)+((-1)^i+1)*sqrt(3)/4;
        yp=y+3*(i-1)/2;
        sf=S3(nu)^pow/(S3(nu)^pow+100^pow);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        axis([-1 34 -1 1])
        hold on
        nu=nu+1;
    end
end
axis off
end


for k=1:simnum
nu=1;
S4=Sv(k,:);
axes('position',[0.735,0.37+0.06*(k-1),0.215,0.04]);
for i=1:m
    for j=1:n
        xp=x+sqrt(3)*(j-1)+((-1)^i+1)*sqrt(3)/4;
        yp=y+3*(i-1)/2;
        sf=S4(nu)^pow/(S4(nu)^pow+100^pow);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        axis([-1 34 -1 1])
        hold on
        nu=nu+1;
    end
end
axis off
end


