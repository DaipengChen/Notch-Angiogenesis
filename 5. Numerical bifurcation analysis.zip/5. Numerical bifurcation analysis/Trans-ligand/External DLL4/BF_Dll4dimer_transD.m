%This code is used to show the bifurcation diagram of VEGF-NOTCH signaling
%in one-cell system.
%Written by Daipeng Chen (Dec 13, 2021)

clc
clear
close all

%% Input data
load('Dll4dimer_bifur1');
load('Dll4dimer_bifur2');

%% Find the bifurcation point
k1=find(Bifur1(16,:)>0);
k2=find(Bifur2(16,:)>0);


%% Output figure
figure(1)
plot(Bifur1(15,1:19689),Bifur1(7,1:19689),'r-','linewidth',1.5)
hold on
plot(Bifur1(15,19689:20041),Bifur1(7,19689:20041),'r-','linewidth',1.5)
hold on
plot(Bifur1(15,20041:end),Bifur1(7,20041:end),'r-','linewidth',1.5)
hold on
plot(Bifur2(15,1:2377),Bifur2(7,1:2377),'k-','linewidth',1.5)
hold on
plot(Bifur2(15,2377:end),Bifur2(7,2377:end),'k--','linewidth',1.5)
axis([0 200 0 250])
xlabel('The level of trans-DLL4 (D_{ext})');
ylabel('VEGFR2 activity (S_v)');
set(gca, 'FontSize',18)


