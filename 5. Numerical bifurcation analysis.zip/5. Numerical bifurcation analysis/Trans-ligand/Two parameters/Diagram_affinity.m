%This code is used to show the bifurcation diagram of VEGF-NOTCH signaling
%in two-cell system.
%Written by Daipeng Chen (Dec 16, 2021)

clc
clear
close all

%% Input data
load('Bifur_diagram');

%% Calculation the edge of boundary
x=Bifur(:,1)'; %Notch level
x1=Bifur(:,2)'; %pitchfork
x2=Bifur(:,3)'; %up-boundary
x3=Bifur(:,4)'; %up-boundary

%% Output figure
fill([x,fliplr(x)],[x1,fliplr(x2)],[0.97,0.56,0.24],'edgecolor','none');
hold on
fill([x,fliplr(x)],[x2,fliplr(x3)],[0.35,0.66,0.35],'edgecolor','none');
alpha(0.75)
axis([0 200 0 0.4]);
text(70,0.08,'patterning','FontSize',20)
text(60,0.27,'no patterning','FontSize',20)
xlabel('The level of trans-JAG1 (J_{ext})')
ylabel('Notch-JAG1 affinity (\alpha)')
set(gca, 'FontSize',18)

