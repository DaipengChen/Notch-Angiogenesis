%This code is used to show the bifurcation diagram of VEGF-NOTCH signaling
%in one-cell system.
%Written by Daipeng Chen (Dec 13, 2021)

clc
clear
close all

%% Input data
load('Dll4dimer_bifur1');
load('Dll4dimer_bifur2');
load('Dll4dimer_bifur3');

%% Find the bifurcation point
k1=find(Bifur1(16,:)>0);
k2=find(Bifur2(16,:)>0);
k3=find(Bifur3(16,:)>0);


%% Output figure
figure(1)
plot(Bifur1(15,1:end),Bifur1(7,1:end),'r-','linewidth',1)
hold on
plot(Bifur2(15,1:2652),Bifur2(7,1:2652),'r-','linewidth',1)
hold on
plot(Bifur2(15,2652:14172),Bifur2(7,2652:14172),'r--','linewidth',1)
hold on
plot(Bifur2(15,14172:20603),Bifur2(7,14172:20603),'r-','linewidth',1)
hold on
plot(Bifur2(15,20603:21314),Bifur2(7,20603:21314),'r--','linewidth',1)
hold on
plot(Bifur2(15,21314:end),Bifur2(7,21314:end),'r-','linewidth',1)
hold on
plot(Bifur3(15,1:350),Bifur3(7,1:350),'k-','linewidth',1)
hold on
plot(Bifur3(15,350:539),Bifur3(7,350:539),'k--','linewidth',1)
hold on
plot(Bifur3(15,539:1089),Bifur3(7,539:1089),'k-','linewidth',1)
hold on
plot(Bifur3(15,1089:2165),Bifur3(7,1089:2165),'k--','linewidth',1)
hold on
plot(Bifur3(15,2165:end),Bifur3(7,2165:end),'k-','linewidth',1)
axis([1 10000 1 10000])
text(1.5,3,'b_J=100','FontSize',15)
xlabel('Production rate of Dll4 in two adjacent cells (b_D)');
ylabel('VEGFR2 activity');
set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
set(gca, 'FontSize',12)


