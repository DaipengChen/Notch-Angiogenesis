function dF=GetODEs(~,w,par)

L0=par(1);kd=par(2);beta=par(3);kt=par(4);
kc=par(5);r=par(6);N0=par(7);

dF=[L0-beta*w(1)-2*kd*w(1)^2-kt*w(7)*w(1);
    kd*w(1)^2-kc*w(2)*w(3)-beta*w(2);
    N0-beta*w(3)-kc*w(2)*w(3)-kt*w(5)*w(3);
    kt*w(5)*w(3)-r*w(4);
    L0-beta*w(5)-2*kd*w(5)^2-kt*w(3)*w(5);
    kd*w(5)^2-kc*w(6)*w(7)-beta*w(6);
    N0-beta*w(7)-kc*w(6)*w(7)-kt*w(1)*w(7);
    kt*w(1)*w(7)-r*w(8)];

end