% This code is used to show the bifurcation diagram of VEGF-NOTCH signaling
% in one-cell system.
% Written by Daipeng Chen (Dec 13, 2021)

clc
clear
close all

% Input data
load('Dll4dimer_bifur1');
load('Dll4dimer_bifur2');
load('Dll4dimer_bifur3');

% Find the bifurcation point
k1=find(Bifur1(16,:)>0);
k2=find(Bifur2(16,:)>0);
k3=find(Bifur3(16,:)>0);

% Parameters
D0=600; %production of ligands
beta=0.1; %degradation rate
N0=500;  %production of Notch
kho=0.0001; %dimerization rate
kt=5*10^(-5); %trans-activation and VEGF-VEGFR binding
kc=6*10^(-4); %trans-activation and VEGF-VEGFR binding
r=0.5;  %degradation rate of signaling of Notch and VEGF
par=[D0 kho beta kt kc r N0];

%% Initial condition
W0=unifrnd(0,100,1,8); %initial value of ODE
T=7000; %calculating period
p = logspace(0,4,100);

%% Calculation
for k = 1:length(p)
    par(1)= 4*p(k);
    [~,Y]=ode45(@GetODEs,0:1:T,W0,[],par);
    out(k)=Y(end,4);
end

%% Output figure
figure(1)
plot(Bifur1(15,1:end),Bifur1(7,1:end),'r-','linewidth',1)
hold on
plot(Bifur2(15,1:4046),Bifur2(7,1:4046),'r-','linewidth',1)
hold on
plot(Bifur2(15,4046:14742),Bifur2(7,4046:14742),'r--','linewidth',1)
hold on
plot(Bifur2(15,14742:20672),Bifur2(7,14742:20672),'r-','linewidth',1)
hold on
plot(Bifur2(15,20672:21346),Bifur2(7,20672:21346),'r--','linewidth',1)
hold on
plot(Bifur2(15,21346:end),Bifur2(7,21346:end),'r-','linewidth',1)
hold on
plot(Bifur3(15,1:304),Bifur3(7,1:304),'k-','linewidth',1)
hold on
plot(Bifur3(15,305:434),Bifur3(7,305:434),'k--','linewidth',1)
hold on
plot(Bifur3(15,434:1007),Bifur3(7,434:1007),'k-','linewidth',1)
hold on
plot(Bifur3(15,1008:2058),Bifur3(7,1008:2058),'k--','linewidth',1)
hold on
plot(Bifur3(15,2058:end),Bifur3(7,2058:end),'k-','linewidth',1)
axis([1 10000 1 10000])
text(1.5,3,'b_J=(25, 100, 200, 2000)','FontSize',15)
xlabel('Production rate of Dll4 in two adjacent cells (b_D)');
ylabel('VEGFR2 activity');
set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
set(gca, 'FontSize',15)


figure(2)
fill([1 Bifur3(15,304) Bifur3(15,304) 1],[0 0 1 1],[0.3,0.52,0.74],'edgealpha', '0');
hold on
fill([Bifur3(15,304) Bifur3(15,434) Bifur3(15,434) Bifur3(15,304)],[0 0 1 1],[0.35,0.66,0.35],'edgealpha', '0');
hold on
fill([Bifur3(15,434) Bifur2(15,21346) Bifur2(15,21346) Bifur3(15,434)],[0 0 1 1],[0.97,0.56,0.24],'edgealpha', '0');
hold on
fill([Bifur2(15,21346) Bifur2(15,4046) Bifur2(15,4046) Bifur2(15,21346)],[0 0 1 1],[0.35,0.66,0.35],'edgealpha', '0');
hold on
fill([Bifur2(15,4046) 10^4 10^4 Bifur2(15,4046)],[0 0 1 1],[0.3,0.52,0.74],'edgealpha', '0');
hold on
plot(p,out/max(out)-0.01,'k','LineWidth',2)
axis([1 10000 0 1])
xlabel('Production rate of Dll4 in two adjacent cells (b_D)');
ylabel('Relative Notch activity');
set(gca, 'XScale', 'log')
set(gca, 'FontSize',15)

