function M=GetContactMatrix(m,n)
num=m*n;
M=zeros(num,num);

for i=1:num
    %% the first column
    if mod(i,n)==1
        M(i,i+1)=1;
        if mod(ceil(i/n),2)==1 % odd row
            if i+n<=num
                M(i,i+n)=1;
                M(i,i+2*n-1)=1;
            end
        else % even row
            if i+n<=num
                M(i,i+n)=1;
                M(i,i+n+1)=1;
            end
        end
    end
    %% the last column
    if mod(i,n)==0
        M(i,i+1-n)=1;
        if mod(ceil(i/n),2)==1 % odd row
            if i+n<=num
                M(i,i+n)=1;
                M(i,i+n-1)=1;
            end
        else % even row
            if i+n<=num
                M(i,i+n)=1;
                M(i,i+1)=1;
            end
        end
    end
    %% other columns
    if mod(i,n)>1
        M(i,i+1)=1;
        if mod(ceil(i/n),2)==1 % odd row
            if i+n<=num
                M(i,i+n)=1;
                M(i,i+n-1)=1;
            end
        else % even row
            if i+n<=num
                M(i,i+n)=1;
                M(i,i+n+1)=1;
            end
        end
    end
end

M=(M+M')/2;

end