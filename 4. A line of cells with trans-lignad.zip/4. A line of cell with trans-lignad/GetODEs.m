function dF=GetODEs(~,w,par,Dext,Jext,Vext,num,M)

% parmeters
D0=par(1);J0=par(2);beta=par(3);kho=par(4);khe=par(5);kt=par(6);kv=par(7);
kc=par(8);N0=par(9);r=par(10);R02=par(11);alpha=par(12);

% ode system
for i=1:num
    if 6<i&&i<15
        dF(7*i-6:7*i,:)=...
        [D0*(10*w(7*i)^2+200^2)/(w(7*i)^2+200^2)-beta*w(7*i-6)-2*kho*w(7*i-6)^2-khe*w(7*i-6)*w(7*i-5)-kt*M(i,:)*w(4:7:7*num)*w(7*i-6);
        J0-beta*w(7*i-5)-khe*w(7*i-6)*w(7*i-5)-alpha*kt*M(i,:)*w(4:7:7*num)*w(7*i-5);
        kho*w(7*i-6)^2-beta*w(7*i-4)-kc*w(7*i-3)*w(7*i-4);
        N0-beta*w(7*i-3)-kt*M(i,:)*(w(1:7:7*num)+alpha*w(2:7:7*num))*w(7*i-3)-kc*w(7*i-4)*w(7*i-3);
        kt*M(i,:)*(w(1:7:7*num)+alpha*w(2:7:7*num))*w(7*i-3)-r*w(7*i-2);
        R02*30^2/(w(7*i-2)^2+30^2)-beta*w(7*i-1)-kv*Vext*w(7*i-1);
        kv*Vext*w(7*i-1)-r*w(7*i)];
    else
        dF(7*i-6:7*i,:)=...
        [D0*(10*w(7*i)^2+200^2)/(w(7*i)^2+200^2)-beta*w(7*i-6)-2*kho*w(7*i-6)^2-khe*w(7*i-6)*w(7*i-5)-kt*M(i,:)*w(4:7:7*num)*w(7*i-6);
        J0-beta*w(7*i-5)-khe*w(7*i-6)*w(7*i-5)-alpha*kt*M(i,:)*w(4:7:7*num)*w(7*i-5);
        kho*w(7*i-6)^2-beta*w(7*i-4)-kc*w(7*i-3)*w(7*i-4);
        N0-beta*w(7*i-3)-kt*M(i,:)*(w(1:7:7*num)+Dext+alpha*(w(2:7:7*num)+Jext))*w(7*i-3)-kc*w(7*i-4)*w(7*i-3);
        kt*M(i,:)*(w(1:7:7*num)+Dext+alpha*(w(2:7:7*num)+Jext))*w(7*i-3)-r*w(7*i-2);
        R02*30^2/(w(7*i-2)^2+30^2)-beta*w(7*i-1)-kv*Vext*w(7*i-1);
        kv*Vext*w(7*i-1)-r*w(7*i)];
    end
end

end