% This code is for investigating the dynamics of VEGF-Delta-Notch signaling
% in two cell system.
% Written by Daipeng Chen (15 Dec, 2021)

clc
clear
close all

%% Parameter setting
D0=100;J0=100;Dext=0;Jext=0;
m=1; %initial cell number in y aixs
n=20; %initial cell number in x axis
p1=[1 5 25 50 75 150 200 250 300];

%% Initial condition
t=-pi/2:pi/3:3*pi/2;
x=sin(t+pi/2);y=cos(t+pi/2); %the shape of cells
simnum=length(p1); %the number of simulations

%% Calculation
for i=1:simnum
    Dext = p1(i);
    [Sv]=linecell(D0,J0,m,n,Dext,Jext);
    S(i,:)=Sv;
end

%% Output figure
axes('position',[0.075,0.15,0.23,0.83]);
fill([0,0.23,0.23,0],[0,0,1,1],[0.8,0.8,0.8],'edgecolor','none');
axis off

pow=5;
annotation('arrow',[0.06,0.06],[0.14,0.98],'LineStyle','-','color','k','LineWidth',2)
text(0.11,-0.08,'1D layer of 20 interacting cells','FontSize',18)
text(-0.05,-0.015,'Trans-DLL4 level in shaded stripes','rotation',90,'fontsize',17)
box on
axis off

axes('position',[0.603,0.15,0.23,0.83]);
fill([0,0.23,0.23,0],[0,0,1,1],[0.8,0.8,0.8],'edgecolor','none');
text(0.295,0.14,'VEGFR2 activity in cells','rotation',90,'fontsize',18);
axis off

for k=1:simnum
nu=1;
Sv=S(k,:);
axes('position',[0.08,0.16+0.095*(k-1),0.75,0.05]);
for i=1:m
    for j=1:n
        xp=x+sqrt(3)*(j-1)+((-1)^i+1)*sqrt(3)/4;
        yp=y+3*(i-1)/2;
        sf=Sv(nu)^pow/(Sv(nu)^pow+100^pow);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        axis([-1 34 -1 1])
        hold on
        nu=nu+1;
    end
end
axis off
end

colormap(summer);
colorbar('color','none','position',[0.839 0.15 0.035 0.83]);

