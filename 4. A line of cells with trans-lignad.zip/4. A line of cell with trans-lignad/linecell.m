function [Sv]=linecell(D0,J0,m,n,Dext,Jext)
%% Parameter setting
beta=0.1; %degradation rate
N0=500;  %production of Notch
kho=0.0001;khe=0.001; %dimerization rate
kt=5*10^(-5);kv=5*10^(-5); %trans-activation and VEGF-VEGFR binding
kc=6*10^(-4); %trans-activation and VEGF-VEGFR binding
r=0.5;  %degradation rate of signaling of Notch and VEGF
R02=800; %production of VEGFRs
alpha=0.0001;
par=[D0 J0 beta kho khe kt kv kc N0 r R02 alpha];
Vext=2500; %VEGF

%% Initial condition
W0=unifrnd(0,100,1,7*m*n); %initial value of ODE
T=5000; %calculating period

%% Contact matrix between cells
M=GetContactMatrix(m,n);

%% Solving ODE by Runge-Kutta solver
[~,W]=ode45(@GetODEs,0:1:T,W0,[],par,Dext,Jext,Vext,m*n,M);

%% Output VEGF signaling
Sv=W(end,7:7:end);

end