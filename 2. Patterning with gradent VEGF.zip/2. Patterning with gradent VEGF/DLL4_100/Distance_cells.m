function D=Distance_cells(m,n)
num=m*n;
D=zeros(num,1);
t=-pi/2:pi/3:3*pi/2;
x0=sin(t);
X0=0;
for i=1:m
    for j=1:n
        x=x0+3*(j-1)/2;
        X=mean(x(1:6));
        k=n*(i-1)+j;
        D(k)=sqrt((X-X0).^2);
    end
end
end