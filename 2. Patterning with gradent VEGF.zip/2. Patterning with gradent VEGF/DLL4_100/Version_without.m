% This code is used to study the vein formation mediated by Notch
% Written by Daipeng Chen (26 July, 2022)
clc
clear
close all

% Parameters
D0=100;J0=100; %production of ligands
beta=0.1; %degradation rate
N0=500;  %production of Notch
kho=0.0001;khe=0.000; %dimerization rate
kt=5*10^(-5);kv=5*10^(-5); %trans-activation and VEGF-VEGFR binding
kc=6*10^(-4); %trans-activation and VEGF-VEGFR binding
r=0.5;  %degradation rate of signaling of Notch and VEGF
R02=800; %production of VEGFRs
alpha=0.0001;
par=[D0 J0 beta kho khe kt kv kc N0 r R02 alpha];
Vmax=2500;

%% Initial condition
t=-pi/2:pi/3:3*pi/2;
x=sin(t);y=cos(t);
m=11;n=12;num=m*n; % cell numbers
W0=unifrnd(0,100,1,7*m*n); %initial value of ODE
T=1000; %calculating period

%% Calculation
% protein production
D=Distance_cells(m,n);
for k=1:n
    P(k)=3*(k-1)/2;
    W1(k)=Vmax/exp(D(k)/1);
end
% VEGFR2 activity
M=GetContactMatrix(m,n);
[~,Y]=ode45(@GetODEs,0:1:T,W0,[],par,m*n,M,D,Vmax);
D4=Y(end,1:7:end);
J1=Y(end,2:7:end);
Sn=Y(end,5:7:end);
Sv=Y(end,7:7:end);


%% Output figures
h=8; %the sharpness of color
figure(1)
t=tiledlayout(1,4);                                    %Requires R2019b or later
nexttile
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        sf=D4(s)^h/(D4(s)^h+300^h);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        hold on
        s=s+1;
    end
end
axis([-1 32.5 -0.9 19.1])
text(17,-6.25,'low','FontSize',19)
text(-0.5,-6.5,'high','FontSize',19)
colormap(summer);
colorbar('color','none','position',[0.08 0.52 0.02 0.35]);
axis off
t.TileSpacing='compact';
set(gca,'XDir','reverse')
view(90,-90)

nexttile
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        sf=J1(s)^h/(J1(s)^h+700^h);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        hold on
        s=s+1;
    end
end
axis([-1 32.5 -0.9 19.1])
axis off
t.TileSpacing='compact';
set(gca,'XDir','reverse')
view(90,-90)

nexttile
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        sf=Sn(s)^h/(Sn(s)^h+100^h);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        hold on
        s=s+1;
    end
end
axis([-1 32.5 -0.9 19.1])
axis off
t.TileSpacing='compact';
set(gca,'XDir','reverse')
view(90,-90)

nexttile
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        sf=Sv(s)^h/(Sv(s)^h+100^h);
        col=[sf sf/2+0.5 0.4];
        fill(xp(1:6),yp(1:6),col);
        hold on
        s=s+1;
    end
end
axis([-1 32.5 -0.9 19.1])
axis off
t.TileSpacing='compact';
set(gca,'XDir','reverse')
view(90,-90)


