function M=GetContactMatrix(m,n)
num=m*n;
M=zeros(num,num);

for i=1:num
    if mod(i,n)>0 % except for the last column
        M(i,i+1)=1;
        if mod(mod(i,n),2)==1 % odd column
            if i+n<=num
                M(i,i+n)=1;
            end
        else % even column
            if i+n<=num
                M(i,i+n-1)=1;
                M(i,i+n)=1;
                M(i,i+n+1)=1;
            end
        end
    end
    
    if mod(i,n)==0 % the last column
        if i+n<=num
            M(i,i+n-1)=1;
            M(i,i+n)=1;
        end
    end
end

M=M+M';
M=M./sum(M,1);

end