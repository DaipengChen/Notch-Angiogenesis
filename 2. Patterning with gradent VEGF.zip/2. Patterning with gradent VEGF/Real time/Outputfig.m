function Outputfig(m,n,D4,J1,Sn,Sv)

close all
t=-pi/2:pi/3:3*pi/2;
x=sin(t);y=cos(t);
f=figure;
f.Position(3:4) = [1100 210];
h=8; %the sharpness of color
s=1;
for i=1:m
    for j=1:n
        xp=x+3*(j-1)/2;
        yp1=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4;
        yp2=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4+25;
        yp3=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4+50;
        yp4=y+sqrt(3)*(i-1)+((-1)^j+1)*sqrt(3)/4+75;
        
        sf1=D4(s)^h/(D4(s)^h+200^h);
        sf2=J1(s)^h/(J1(s)^h+110^h);
        sf3=Sn(s)^h/(Sn(s)^h+150^h);
        sf4=Sv(s)^h/(Sv(s)^h+75^h);
        
        col1=[sf1 sf1/2+0.5 0.4];
        col2=[sf2 sf2/2+0.5 0.4];
        col3=[sf3 sf3/2+0.5 0.4];
        col4=[sf4 sf4/2+0.5 0.4];
        
        fill(xp(1:6),yp1(1:6),col1);
        hold on
        fill(xp(1:6),yp2(1:6),col2);
        hold on
        fill(xp(1:6),yp3(1:6),col3);
        hold on
        fill(xp(1:6),yp4(1:6),col4);
        hold on
        s=s+1;
    end
end
axis([-1 17.5 -0.9 94.1])
axis off
text(9,3,'DLL4 level','FontSize',16,'Color','r','FontWeight','bold')
text(9,28,'JAG1 level','FontSize',16,'Color','r','FontWeight','bold')
text(9,51,'Notch activity','FontSize',16,'Color','r','FontWeight','bold')
text(9,75,'VEGFR2 activity','FontSize',16,'Color','r','FontWeight','bold')
set(gca,'XDir','reverse')
view(90,-90)

pause(1)

end