clc
clear
close all
gif2avi('cells_v.gif')