% This code is used to study the vein formation mediated by Notch
% Written by Daipeng Chen (26 July, 2022)
clc
clear
close all

% Parameters
D0=100;J0=100; %production of ligands
beta=0.1; %degradation rate
N0=500;  %production of Notch
kho=0.0001;khe=0.001; %dimerization rate
kt=5*10^(-5);kv=5*10^(-5); %trans-activation and VEGF-VEGFR binding
kc=6*10^(-4); %trans-activation and VEGF-VEGFR binding
r=0.5;  %degradation rate of signaling of Notch and VEGF
R02=800; %production of VEGFRs
alpha=0.0001;
par=[D0 J0 beta kho khe kt kv kc N0 r R02 alpha];
Vmax=2500;

%% Initial condition
t=-pi/2:pi/3:3*pi/2;
x=sin(t);y=cos(t);
m=11;n=12;num=m*n; % cell numbers

W0=unifrnd(0,150,1,7*m*n); % initial value of ODE
W0(1:7:end)=unifrnd(0,400,1,m*n); % initial value of ODE
W0(2:7:end)=unifrnd(0,250,1,m*n); % initial value of ODE
W0(5:7:end)=unifrnd(0,300,1,m*n); % initial value of ODE

T=1500; %calculating period

%% Calculation
% protein production
D=Distance_cells(m,n);
% VEGFR2 activity
M=GetContactMatrix(m,n);
[~,X]=ode45(@GetODEs,0:0.01:T,W0,[],par,m*n,M,D,Vmax);

label=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,25,30,35,40,50,...
    60,70,80,90,100,120,140,160,180,200,220,240,260,280,300,350,400,450,500,...
    550,600,650,700,750,800,850,900,950,1000,1500,2000,2500,3000,3500,4000,4500,5000,...
    5500,6000,6500,7000,7500,8000,8500,9000,9500,10000,12500,15000,17500,20000,...
    25000,30000,35000,40000,50000,60000,70000,80000,90000,100000,120000,150000]';
Y=X(label,:);

%% Output figures
for i=1:length(Y(:,1))
    D4=Y(i,1:7:end);
    J1=Y(i,2:7:end);
    Sn=Y(i,5:7:end);
    Sv=Y(i,7:7:end);
    Outputfig(m,n,D4,J1,Sn,Sv)
    mov(i) = getframe;
    disp(i);
end

movie2gif(mov,'cells_v.gif','LoopCount',0,'DelayTime',0.1);

